package com.example.ProyectoCooperativa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoCooperativaApplicationTests {

	@Test
	void contextLoads() {
	}

}
