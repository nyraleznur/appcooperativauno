package com.example.ProyectoCooperativa.controlador;

import com.example.ProyectoCooperativa.entidades.Cliente;
import com.example.ProyectoCooperativa.servicios.ServicioCliente;
import com.example.ProyectoCooperativa.servicios.ServicioImpCliente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
//@Controller


@Controller
public class ControladorCliente {

    @Autowired
    private ServicioImpCliente sic;
    @GetMapping("cliente")
    public String listarclientes(Model modelo) {
        modelo.addAttribute("clientes",sic.listarClientes());
        return ("clientes");
    }

    @GetMapping("buscar/{b}")
    public Cliente consultar(@PathVariable("b") String id){
        return sic.consultaClientesPorId(id);
    }

    @GetMapping("/cliente/nuevo")

    public String formularioregistrocliente(Model modelo){
        modelo.addAttribute("clienteinsertar", new Cliente());
        return "insertarcliente";
    }

    @PostMapping("cliente/guardar")
    public String guardarcliente (Cliente clie){
          sic.guardarClientes(clie);
        return "redirect:/cliente";
    }

   /*@PostMapping("guardar")
    public Cliente insertar(@RequestBody Cliente cli){
        return sic.guardarClientes(cli);
    }

    @PutMapping("actuakizar")
    public Cliente actualizar(@RequestBody Cliente cli){
        return sic.actualizarClientes(cli);
    }*/

    //@DeleteMapping
   // public void eliminar(@RequestBody Cliente cli){
   //     sic.eliminarClientes(cli.getDocumento());
    //}

    @DeleteMapping("eliminar/{id}")
    public void eliminarpoId(@PathVariable("id") String id){
        sic.eliminarClientesId(id);
    }

 /*   @PatchMapping("act/{id}")
     public Cliente actualizarpor(@PathVariable("id")String id, @RequestBody Map<Object,Object> objectMap){
       return sic.actualizarPorId(id,objectMap);
   }*/


    @GetMapping("/clientes/actualizar/{id}")
    public String mostrarfrmeditarcliente(@PathVariable("id")String id,Model modelo){
        //clienterep.findById(id).get();
        Cliente cliente=sic.consultaClientesPorId(id);
        modelo.addAttribute("clienteinsertar", cliente);
        return "actualizarcliente";
    }


    @PostMapping("cliente/actualizar")
    public String actualizarcliente (Cliente clie){
        sic.actualizarClientes(clie);
        return "redirect:/cliente";
    }

}
